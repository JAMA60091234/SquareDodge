﻿
using UnityEngine;

public class playercollison : MonoBehaviour {

	public playermovment movement;


	void OnCollisionEnter (Collision collisionInfo)
	{
		if (collisionInfo.collider.tag == "obstacle") 
		{
			movement.enabled = false;
			FindObjectOfType<gamemanger> ().EndGame();
		}
	}
}
