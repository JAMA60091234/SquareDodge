﻿using UnityEngine;

public class endtrigger : MonoBehaviour {

	public gamemanger GameManager;

	void OnTriggerEnter ()
	{
		GameManager.CompleteLevel();
	}

}
